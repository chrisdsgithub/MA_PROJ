package com.example.model;

public enum Role {
    USER,
    ADMIN
}
