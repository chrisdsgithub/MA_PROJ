package com.example.model;


public enum UserRole {
    ADMIN,
    USER
}
